<template>
  <div class="color">
    <!-- Formulario de Contacto-->
  <div class="container">
  <form>
    <h3 class="pb-5 text-white"> Únete a nuestro Newsletter</h3>
    <div class="form-row">
      <div class="form-group col-md-12 text-white">
          <label for="inputEmail4">Nombre Completo</label>
          <input type="email" class="form-control" id="inputEmail4">
        </div>
      </div>
      <div class="form-row text-white">
      <div class="form-group col-md-12 pt-2">
        <label for="inputEmail4">Email</label>
        <input type="email" class="form-control" id="inputEmail4">

      </div>
    </div>
    <div class="form-row pt-2">
    <button type="submit" class="btn btn-primary">Sign in</button>
    </div>
  </form>
  </div>
  </div>

</template>

<style scoped>
.color {
  height:100vh;
  background-repeat: no-repeat;
  background-size: cover;
  background-image: url(https://estaticos.muyinteresante.es/uploads/images/gallery/58402b605cafe8877e8b456c/peliculas.jpg);
  padding-top: 7%;
}
.container{
  width: 30%;
}







</style>

