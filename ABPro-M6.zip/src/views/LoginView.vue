<template>
<InicioLogin />
</template>

<script>
import InicioLogin from "@/components/InicioLogin.vue";


export default{
  name: "LoginView",
  components: {
    InicioLogin,
  }
}
</script>
<style>

</style>